# BusinessHelper — Online SaaS starter

BusinessHelper is a multi-company hiring workspace based on the existing UI prototype, upgraded with server-side persistence and document storage.

## Included
- Separate Candidate / Recruiter entry
- Employer registration/login/logout
- Server-side password hashing + signed HTTP-only session cookie
- Password-reset token flow (real email when SMTP is configured)
- Organization-isolated jobs/candidates/emails
- Candidate public application endpoint
- PDF uploads stored on the server instead of browser IndexedDB
- Recruiter PDF viewing/downloading through authenticated routes
- Candidate application access token
- SMTP email sending adapter
- Rate limiting on auth/public API routes
- bcrypt password hashing
- Health endpoint
- Server-side AI screening endpoint (provider key never exposed to browser)
- SQLite database for local/small deployments
- Dockerfile

## Important production note
This package is deployable, but it is not the same as already having a public domain. A hosting account, domain, database/storage plan, and email credentials are required to publish it. For serious production traffic, replace local SQLite/uploads with managed PostgreSQL + private object storage (S3-compatible/Supabase Storage) and put the app behind HTTPS. The included local adapter is intentionally simple so the app can run immediately; managed infrastructure should be configured before handling real candidate documents at scale.

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set a long random `JWT_SECRET`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Real company email
Set SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS and SMTP_FROM in `.env`. Use a mailbox/domain you control and have verified with your email provider.

## Recommended production architecture
- App: Node/Express behind HTTPS
- Database: PostgreSQL
- Private documents: S3-compatible object storage with signed URLs
- Email: verified transactional email provider/SMTP
- AI: server-side provider key only; never expose an AI secret in browser JavaScript
- Auth: HTTP-only secure cookies, rate limiting, MFA/OTP for employer accounts
- Security: malware scanning, audit logs, retention/deletion controls, tenant isolation, backups

## AI configuration
Set `AI_API_URL`, `AI_API_KEY`, and optionally `AI_MODEL` on the server. The endpoint expects an OpenAI-compatible chat-completions style response. Keep the key server-side only.

## AI hiring safety
The UI's AI recommendation is decision support. It should not make the final hiring decision and should not use protected/sensitive personal characteristics. HR remains responsible for the final decision.
