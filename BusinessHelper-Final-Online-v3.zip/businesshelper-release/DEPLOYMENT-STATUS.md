# BusinessHelper release status

## Completed
- Supabase project connected and BusinessHelper PostgreSQL schema created.
- Private `candidate-documents` storage bucket created/configured for PDF files.
- Employer auth, password hashing, reset flow, rate limiting and HTTP-only sessions exist in the Node runtime.
- Candidate access now uses one-time email verification flow in the browser UI.
- Candidate/recruiter PDF upload and document viewing routes are protected.
- Production-oriented environment configuration is included.

## Important
This package is deployment-ready, but it is **not a public live website yet**. A hosting provider must run the server and receive its environment secrets. Do not put service-role keys in frontend code.

The current `server.js` is the stable Node/SQLite runtime. The Supabase project has the hosted PostgreSQL/storage schema ready; completing the runtime cutover requires the hosting environment to receive `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` and the hosted migration runtime to be deployed.

## Required hosting setup
1. Connect a hosting provider such as Render.
2. Deploy this Node service from the project folder.
3. Set `NODE_ENV=production`, `JWT_SECRET`, `APP_URL`, SMTP variables and AI variables as needed.
4. For the Supabase cutover, set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` only on the server.
5. Configure a verified sender/domain for real email delivery.
6. Test `/api/health`, employer registration/login, candidate application, PDF upload/view, candidate OTP, password reset and email delivery from a second device.

Never commit `.env` or any service-role/secret key.
